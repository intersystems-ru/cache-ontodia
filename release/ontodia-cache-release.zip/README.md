# Ontodia-cache class viewer

An Ontodia Class explorer for InterSystems Caché.


## Site ontodia

http://www.ontodia.org


## Installation

To install latest Ontodia-cache class viewr, you just need to import OntodiaCache package. Download the
archive, and then import
<code>OntodiaCache.xml</code> file two times.
In first time the web-applications will be created.
In second time the app resources will downloaded.

## Using

After instalation will be completed, you can go to {server url}/csp/ontodia-cache/index.html to view classes of cpecified namespace.
Url parameters:
namespace: string - cpecified namespace. (By default = 'Samples').

Example:
http://localhost:57772/csp/ontodia-cache/index.html?namespace=Samples


## Build

To build project, you need [NodeJS](https://nodejs.org) platform to be installed. Then, clone source
code and run <code>npm install</code> from the root of the project. This will install all necessary
modules from NPM for the project.

After that and each next time just run <code>npm run webpack</code> command from the project root.
This will generate sourse code, which can be moved to intersystems cache studion to creating new version of application.
